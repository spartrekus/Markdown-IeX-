
///////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <string.h>
//
#include <ctype.h>  // fexist
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
//
#include <unistd.h>  //define getcwd
///////////////////////////////////////////////////////////////////



int sectionnbr    = 1;
int subsectionnbr = 1;

char *strnlf( char *linetmp ){
      int i , j , k ;
      char line[PATH_MAX];

			  // rem last \n
			  // start
			  strncpy( line, "" , PATH_MAX );
			  for( i = 0 ; ( i <= strlen( linetmp ) ); i++ )
			     if ( linetmp[i] != '\n' )
			     if ( linetmp[i] != '\r' )
				line[i]=linetmp[i];
			   // end

   size_t siz = sizeof line ; 
   char *r = malloc( sizeof line );
   return r ? memcpy(r, line, siz ) : NULL;
}




//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////
char *strcut( char *aoption , int cutstart  , int lengthexttmp ){
  char buffer[PATH_MAX];
  char charo[PATH_MAX];

  int lengthext=0;
  lengthext = lengthexttmp;
  if ( lengthexttmp > strlen( aoption) ) 
     lengthext = strlen( aoption );

  int i, chd, cx , j ; 
  strncpy( buffer, "" , PATH_MAX);

  if ( lengthext <= strlen( aoption) )
  {
    for ( i= cutstart ;  ( i <= lengthext )  ; i++ ) 
    {
      j = snprintf( charo, 5 , "%c", aoption[i]);
      strncat( buffer , charo , PATH_MAX - strlen(buffer) - 1);
    }
  }
  else
    j = snprintf( buffer, PATH_MAX , "%s", aoption);
  size_t len = strlen(buffer);
  char *r = malloc(len+1);
  return r ? memcpy(r, buffer, len+1) : NULL;
}




int fexist(char *a_option)
{
  char dir1[PATH_MAX]; 
  char *dir2;
  DIR *dip;
  strncpy( dir1 , "",  PATH_MAX  );
  strncpy( dir1 , a_option,  PATH_MAX  );
  struct stat st_buf; 
  int status; 
  int fileordir = 0 ; 
  status = stat ( dir1 , &st_buf);
  if (status != 0) {
    fileordir = 0;
  }
  FILE *fp2check = fopen( dir1  ,"r");
  if( fp2check ) {
    fileordir = 1; 
    fclose(fp2check);
  } 
  if (S_ISDIR (st_buf.st_mode)) {
    fileordir = 2; 
  }
  return fileordir;
}







void filenew( char *fileout)
{
    FILE *fp5;
    fp5 = fopen( fileout , "wb+");
    fclose( fp5 );
}


void fileclosertf( char *fileout)
{
    FILE *fp5;
     // close the rtf
     fp5 = fopen( fileout , "ab+"); 
	 fputs( "\\par }\n", fp5 );
     fclose( fp5 );
}





///////////////////////////////////////////////////////////////////
void filerawcat(  char *fileout, char *filein ){
  int fetchi;
  FILE *fp5;
  FILE *fp6;
  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];
  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    fp5 = fopen( fileout , "ab+");
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
          fgets(fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline, "" , PATH_MAX );
          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
              fetchline[fetchi]=fetchlinetmp[fetchi];

         if ( !feof(fp6) )
         {
 	      fputs( fetchline , fp5 );
  	      fputs( "\n", fp5 );
	 }
     }
     fclose( fp5 );
     fclose( fp6 );
   }
}





///////////////////////////////////////////////////////////////////
void fileiex2rtf( int filemode , char *fileout, char *filein ){
  int fetchi;
  int i , j , k ; 
  FILE *fp5;
  FILE *fp6;
  char charo[PATH_MAX];
  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];
  int foundcode = 0;
  int foundlinefeed = 0;
  int commenton = 0;
  int fpreader = 1;

           //////////////////////////
           //////////////////////////
           //////////////////////////
           void addlinefeed()
           {
	        fputs( "\\par " , fp5 );
           }

  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    fp5 = fopen( fileout , "ab+");
    fp6 = fopen( filein , "rb+");
    // while( !feof(fp6) ) 
    while ( ( !feof(fp6) ) &&  ( fpreader == 1 ) )
    {
          fgets(fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline, "" , PATH_MAX );
          foundcode = 0;

          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
              fetchline[fetchi]=fetchlinetmp[fetchi];

         if ( ( !feof(fp6) ) &&  ( fpreader == 1 ) )
         {

            /////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '/' )
            if ( fetchline[1] == '*' )
            {
  	      commenton = 1;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '*' )
            if ( fetchline[1] == '/' )
            {
  	      commenton = 0;
    	      foundcode = 1;
            }

            if ( commenton == 1 )
            {
    	      foundcode = 1;
            }
            /////////////////////////////////////
            /////////////////////////////////////

            if ( foundcode == 0 )
            if ( fetchline[0] == '/' )
            if ( fetchline[1] == '/' )
            {
  	        foundcode = 1;
  	        foundcode = 1;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'r' )
            if ( fetchline[3] == 'e' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 'k' )
            {
  	      fpreader = 0;
  	      foundcode = 1;
            }
            /////////////////////////////////////
            /////////////////////////////////////









/*
 \par {\i italic }
 \par {\cf6 This is red}
 \par {\cf2 This is blue}
 \par {\cf17 This is green}
*/

	    //////////////////////////////////
            if ( foundcode == 0 )
            if ( strcmp(fetchline, "" ) == 0 )
            {
              if ( foundlinefeed == 0 )
	      {
	        addlinefeed();
  	        fputs( "\n", fp5 );
                foundlinefeed = 1;
	      }
	      else 
	      {
	      }
  	      foundcode = 1;
            }


            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'g' )
            if ( fetchline[2] == 'r' )
            if ( fetchline[3] == 'e' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == 'n' )
            if ( fetchline[6] == ' ' )
            {
 	      fputs( "{\\cf17 " , fp5 );
 	      fputs( strcut( fetchline, 7, strlen(fetchline)-1) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'l' )
            if ( fetchline[3] == 'u' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == ' ' )
            {
 	      fputs( "{\\cf2 " , fp5 );
 	      fputs( strcut( fetchline, 6, strlen(fetchline)-1) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'r' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'd' )
            if ( fetchline[4] == ' ' )
            {
 	      fputs( "{\\cf6 " , fp5 );
 	      fputs( strcut( fetchline, 5, strlen(fetchline)-1) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }


            // reader comments
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'm' )
            if ( fetchline[4] == ' ' )
            {
 	      fputs( "{\\cf6  [" , fp5 );
 	      fputs( strcut( fetchline, 5, strlen(fetchline)-1) , fp5 );
  	      fputs( "]} ", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }





            if ( foundcode == 0 )
            if ( fetchline[0] == '#' )
            if ( fetchline[1] == '#' )
            if ( fetchline[2] == ' ' )
            {
	      addlinefeed();
 	      fputs( "{\\b " , fp5 );
              j = snprintf( charo, 25 , "%d.%d. ", sectionnbr, subsectionnbr );
 	      fputs( charo, fp5 );
 	      fputs( strcut( fetchline, 3, strlen(fetchline)-1) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '#' )
            if ( fetchline[1] == ' ' )
            {
	      addlinefeed();
 	      fputs( "{\\b " , fp5 );
              j = snprintf( charo, 5 , "%d. ", sectionnbr++ );
 	      fputs( charo, fp5 );
 	      fputs( strcut( fetchline, 2, strlen(fetchline)-1) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '>' )
            if ( fetchline[1] == ' ' )
            {
	      addlinefeed();
 	      fputs( "{\\b " , fp5 );
 	      fputs( strcut( fetchline, 2, strlen(fetchline)-1) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '-' )
            if ( fetchline[1] == ' ' )
            {
	      addlinefeed();
 	      fputs( "- " , fp5 );
 	      fputs( strcut( fetchline, 2, strlen(fetchline)-1) , fp5 );
  	      fputs( "", fp5 );
  	      fputs( "\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }





            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'l' )
            if ( fetchline[4] == 'd' )
            if ( fetchline[5] == ' ' )
            {
	      addlinefeed();
 	      fputs( "{\\b " , fp5 );
 	      fputs( strcut( fetchline, 6, strlen(fetchline)-1) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'l' )
            if ( fetchline[5] == ' ' )
            {
	      addlinefeed();
 	      fputs( "{\\i " , fp5 );
 	      fputs( strcut( fetchline, 6, strlen(fetchline)-1) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }



  	    if ( foundcode == 0 )
  	    if ( strcmp( fetchline, "" ) != 0 )
            {
 	      fputs( fetchline , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }

	 }
     }
     fclose( fp5 );
     fclose( fp6 );

   }
}






int main( int argc, char *argv[])
{ 
    char cwd[PATH_MAX];


    ////////////////////////////////////////////////////////
    if ( argc == 2)
     if ( strcmp( argv[1] , "" ) !=  0 ) 
     {
	    printf( "Target not found \n" );
	    return 0; 
     }

    ////////////////////////////////////////////////////////
    if ( argc == 3)
     if ( strcmp( argv[1] , "" ) !=  0 ) 
     if ( strcmp( argv[2] , "" ) !=  0 ) 
     {
          filenew( argv[2] );

          if ( fexist( "/usr/share/markdown/headerrtf.dat" ) == 1 )
             filerawcat( argv[2] , "/usr/share/markdown/headerrtf.dat" );
          else
             filerawcat( argv[2] , "headerrtf.dat" );

          fileiex2rtf( 1, argv[2] , argv[1] );
          fileclosertf( argv[2] );
          return 0;
     }

    ////////////////////////////////////////////////////////
    if ( argc == 3)
      if ( strcmp( argv[1] , "--open" ) ==  0 ) 
      if ( strcmp( argv[2] , "" ) !=  0 ) 
      {
          strncpy( cwd , "  " , PATH_MAX );
          strncat( cwd , " wine ~/.wine/drive_c/Program\\ Files/Microsoft\\ Office/Office/WINWORD.EXE " , PATH_MAX - strlen( cwd ) -1 );
          strncat( cwd , " \"" , PATH_MAX - strlen( cwd ) -1 );
          strncat( cwd , argv[2] , PATH_MAX - strlen( cwd ) -1 );
          strncat( cwd , "\" " , PATH_MAX - strlen( cwd ) -1 );
          system( cwd );
          return 0;
      }

      return 0;
}



