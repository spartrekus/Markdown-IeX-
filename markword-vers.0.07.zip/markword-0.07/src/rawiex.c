
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <fcntl.h> 
#include <unistd.h> 


 int cat_fd(int ifd, int ofd)
 {
      char buffer[4096];
      ssize_t nbytes;
      while ((nbytes = read(ifd, buffer, sizeof(buffer))) > 0)
      {
          if (write(ofd, buffer, nbytes) != nbytes)
             return -1;
          }
          return (nbytes < 0) ? -1 : 0;
 }



int main( int argc, char *argv[])
{ 

             for (int i = 1; i < argc; i++)
             {
                 int fd = open( argv[i] , O_RDONLY );
                 if (fd < 0)
                     fprintf(stderr, "failed to open %s for reading\n", argv[i]);
                 else
                 {
                     if (cat_fd(fd, 1) != 0)
                         fprintf(stderr, "failed to copy %d to standard output\n", argv[i]);
                     close(fd);
                 }
             }

     return 0;
}



