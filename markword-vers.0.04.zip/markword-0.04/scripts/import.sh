 wine ~/.wine/drive_c/Program\ Files/Microsoft\ Office/Office/WINWORD.EXE "$1"



